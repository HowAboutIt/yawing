#ifndef TA_UART_32KHZ_9600
#define TA_UART_32KHZ_9600

extern unsigned char TI_RXData;
extern unsigned char TI_TA_UART_StatusFlags;

#define   TI_TA_TX_READY    0x01
#define   TI_TA_RX_RECEIVED 0x02

extern void TI_initTimer(int (*callBack)(unsigned char));
extern void TI_setCallbackFunction(int (*callBack)(unsigned char));
extern void TI_TX_Byte( unsigned char c );

#define TA_UART_EXIT_LPM            1
#define TA_UART_STAY_LPM            0

#endif
