#ifndef TA_UART
#define TA_UART

extern unsigned char TI_RXData;
extern unsigned char TI_TA_UART_StatusFlags;

#define   TI_TA_TX_READY    0x01
#define   TI_TA_RX_RECEIVED 0x02

extern void TI_initTimer(int (*callBack)(unsigned char), unsigned int Bitime, unsigned int clock_source);
extern void TI_setCallbackFunction(int (*callBack)(unsigned char));
extern int TI_TX_Byte( unsigned char c );

#define TA_UART_EXIT_LPM            1
#define TA_UART_STAY_LPM            0

//2Mhz
#define _2MHz_SMCLK_19200_Bitime    104

#define _2MHz_SMCLK_09600_Bitime    208

#define _2MHz_SMCLK_04800_Bitime    416

#define _2MHz_SMCLK_02400_Bitime    833

//1Mhz
#define _1MHz_SMCLK_19200_Bitime    52

#define _1MHz_SMCLK_09600_Bitime    104

#define _1MHz_SMCLK_04800_Bitime    208

#define _1MHz_SMCLK_02400_Bitime    416

#define _32Khz_ACLK_02400_Bitime    14

#define _32Khz_ACLK_04800_Bitime    7

#endif
