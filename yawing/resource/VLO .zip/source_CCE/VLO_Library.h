#ifndef VLO_Library
#define VLO_Library

extern int  TI_measureVLO( void );

extern unsigned int TI_8MHz_Counts_Per_VLO_Clock;

#endif
