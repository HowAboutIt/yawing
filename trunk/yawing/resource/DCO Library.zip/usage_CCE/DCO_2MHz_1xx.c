//******************************************************************************
//  MSP430x11x1 Demo - Basic Clock, Output Buffered SMCLK, ACLK and MCLK/10
//
//  Description: Buffer ACLK on P2.0, default SMCLK(DCO) on P1.4 and MCLK/10 on
//  P1.1. To measure SMCLK on P1.4 with the FET, use "Release JTAG on Go"
//  in the debugger to have access to the port. Then run the code.
//  ACLK = LFXT1 = 32768, MCLK = SMCLK = 2MHz
//  //* External watch crystal installed on XIN XOUT is required for ACLK *//	
//
//               MSP430F1121
//             -----------------
//         /|\|              XIN|-
//          | |                 | 32kHz
//          --|RST          XOUT|-
//            |                 |
//            |       P1.4/SMCLK|-->SMCLK = ~2Mhz
//            |             P1.1|-->MCLK/10 = DCO/10
//            |        P2.0/ACLK|-->ACLK = 32kHz
//
//  L. Westlund
//  Texas Instruments Inc.
//  March 2006
//  Built with IAR Embedded Workbench Version: 3.40A
//******************************************************************************

#include <msp430x11x1.h>
#include "DCO_Library.h"

void main(void)
{
  volatile unsigned int i;
  int result;
  WDTCTL = WDTPW +WDTHOLD;                  // Stop Watchdog Timer
  P1DIR |= 0x12;                            // P1.1 and P1.4 outputs
  P1SEL |= 0x10;                            // P1.4 SMCLK output
  P2DIR |= 0x01;                            // P2.0 output
  P2SEL |= 0x01;                            // P2.0 ACLK output
  for( i = 0; i < 0xFFFF; i++){}            // delay for ACLK startup
  //BCSCTL2 |= DCOR;                        // if faster speeds are needed, uncomment
  result = TI_SetDCO(TI_DCO_2MHZ);
  if( result == TI_DCO_SET_TO_SLOWEST )     // returned result if DCO registers hit min
  {
    while(1);                               // trap the CPU if hit
  }
  else if( result == TI_DCO_SET_TO_FASTEST )// returned result if DCO registers hit max
  {
    while(1);                               // trap the CPU if hit
  }
  else if( result == TI_DCO_TIMEOUT_ERROR ) // returned result if DCO takes >10000 loops
  {
    while(1);                               // trap the CPU if hit
  }
  while(1)
  {
    P1OUT |= 0x02;                          // P1.1 = 1
    P1OUT &= ~0x02;                         // P1.1 = 0
  }
}
